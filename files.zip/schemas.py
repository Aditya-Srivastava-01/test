# backend/schemas.py
from pydantic import BaseModel
from datetime import datetime


class TacticalEventResponse(BaseModel):
    id: int
    match_id: int
    timestamp: float
    event_type: str
    description: str
    advice: str
    created_at: datetime

    model_config = {"from_attributes": True}
