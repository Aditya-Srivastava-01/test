# CoachAI — Tactical Recommendation Engine

AI-powered coaching advice streamed live during a simulated soccer match. At the 30-second mark, a **Defensive Collapse** is detected and Gemini generates real-time tactical advice pushed to the web client.

---

## Quick Start

```bash
# 1. Clone & enter the project
cd coach-ai/backend

# 2. Create virtualenv and install deps
python -m venv venv && source venv/bin/activate   # Windows: venv\Scripts\activate
pip install -r requirements.txt

# 3. Set up environment
cp .env.example .env
# Edit .env and add your GEMINI_API_KEY (optional — fallback works without it)

# 4. Generate match data
python mock_data_generator.py    # → creates mock_match.json (600 frames)

# 5. Start the server
uvicorn main:app --reload --host 0.0.0.0 --port 8000

# 6. Open the client
open ../web_client/index.html    # or just double-click it in your file manager
```

Then click **▶ START MATCH** and wait ~30 seconds for the coaching banner to appear.

---

## How It Works

| Step | What Happens |
|------|-------------|
| 1 | `mock_data_generator.py` creates 600 frames of 22-player coordinate data |
| 2 | FastAPI WebSocket streams one frame per 0.1s (10 fps) |
| 3 | `agentic_coach.analyze_frame()` checks each frame — triggers at frame 300 |
| 4 | `get_coaching_advice()` calls Gemini API (or uses fallback) |
| 5 | Coaching message pushed to browser; red banner appears |
| 6 | Event stored in SQLite via SQLAlchemy |

## API Endpoints

- `GET /` — health check
- `WS /ws/live-match/{match_id}` — live frame stream
- `GET /events` — retrieve past tactical events from DB

## Fallback (No API Key)

Without a `GEMINI_API_KEY`, the system returns:

> *"Defensive Collapse detected! Instruct the right-back to tuck in and the central midfielder to drop deeper."*
