# backend/agentic_coach.py
import os
import logging
import httpx
from dotenv import load_dotenv

load_dotenv()
logger = logging.getLogger(__name__)

FALLBACK_ADVICE = (
    "Defensive Collapse detected! Instruct the right-back to tuck in and "
    "mark the overlapping winger. The central midfielder must drop deeper "
    "to cover the exposed channel immediately."
)

TRIGGER_FRAME = 300  # 30 seconds at 10 fps


def analyze_frame(frame_index: int, player_data: list) -> tuple[bool, str, str]:
    """
    Mock GNN analysis. Triggers a Defensive Collapse at frame 300.
    Returns (triggered, event_type, description).
    """
    if frame_index == TRIGGER_FRAME:
        return True, "Defensive Collapse", "Right flank exposed — fullback pulled wide, gap behind."
    return False, "", ""


async def get_coaching_advice(event_type: str, description: str) -> str:
    """
    Calls Gemini API to generate 2-sentence coaching advice.
    Falls back to hardcoded advice on any error.
    """
    api_key = os.getenv("GEMINI_API_KEY", "")
    if not api_key:
        logger.warning("No GEMINI_API_KEY set — using fallback advice.")
        return FALLBACK_ADVICE

    prompt = (
        f"You are an elite soccer coach mid-match. A tactical breakdown has occurred: "
        f"'{event_type}' — {description}. "
        f"Give a precise, urgent 2-sentence coaching instruction to fix this immediately. "
        f"Be specific about player positions and actions."
    )

    payload = {
        "contents": [{"parts": [{"text": prompt}]}],
        "generationConfig": {"maxOutputTokens": 120, "temperature": 0.7},
    }

    url = (
        f"https://generativelanguage.googleapis.com/v1beta/models/"
        f"gemini-pro:generateContent?key={api_key}"
    )

    try:
        async with httpx.AsyncClient(timeout=10.0) as client:
            resp = await client.post(url, json=payload)
            resp.raise_for_status()
            data = resp.json()
            text = data["candidates"][0]["content"]["parts"][0]["text"]
            logger.info(f"Gemini response: {text[:80]}...")
            return text.strip()
    except Exception as e:
        logger.error(f"Gemini API error: {e} — using fallback advice.")
        return FALLBACK_ADVICE
