# backend/mock_data_generator.py
import json
import random
import math
from dataclasses import dataclass, field
from typing import Optional

# Formation zones: each player has a (x_min, x_max, y_min, y_max) bounding box
HOME_ZONES = [
    (5,  20, 45, 55),  # GK
    (10, 30, 10, 30),  # LB
    (10, 30, 30, 50),  # CB1
    (10, 30, 50, 70),  # CB2
    (10, 30, 70, 90),  # RB
    (25, 50, 20, 40),  # LM
    (25, 50, 35, 55),  # CM1
    (25, 50, 50, 70),  # CM2
    (25, 50, 65, 85),  # RM
    (45, 70, 30, 55),  # CF1
    (45, 70, 45, 70),  # CF2
]

AWAY_ZONES = [
    (80, 95, 45, 55),  # GK
    (70, 90, 10, 30),  # LB
    (70, 90, 30, 50),  # CB1
    (70, 90, 50, 70),  # CB2
    (70, 90, 70, 90),  # RB
    (50, 75, 20, 40),  # LM
    (50, 75, 35, 55),  # CM1
    (50, 75, 50, 70),  # CM2
    (50, 75, 65, 85),  # RM
    (30, 55, 30, 55),  # CF1
    (30, 55, 45, 70),  # CF2
]


@dataclass
class Player:
    id: int
    team: str
    zone: tuple
    x: float = 0.0
    y: float = 0.0
    target_x: float = 0.0
    target_y: float = 0.0
    speed: float = field(default_factory=lambda: random.uniform(0.3, 0.6))

    def __post_init__(self):
        xmin, xmax, ymin, ymax = self.zone
        self.x = random.uniform(xmin, xmax)
        self.y = random.uniform(ymin, ymax)
        self._pick_target()

    def _pick_target(self):
        xmin, xmax, ymin, ymax = self.zone
        self.target_x = random.uniform(xmin, xmax)
        self.target_y = random.uniform(ymin, ymax)

    def update(self):
        dx = self.target_x - self.x
        dy = self.target_y - self.y
        dist = math.hypot(dx, dy)
        if dist < 1.0:
            self._pick_target()
        else:
            self.x += (dx / dist) * self.speed + random.uniform(-0.1, 0.1)
            self.y += (dy / dist) * self.speed + random.uniform(-0.1, 0.1)
            # Clamp to zone
            xmin, xmax, ymin, ymax = self.zone
            self.x = max(xmin, min(xmax, self.x))
            self.y = max(ymin, min(ymax, self.y))


def generate_match_data(duration_seconds: int = 60, fps: int = 10) -> list[dict]:
    players: list[Player] = []

    for i, zone in enumerate(HOME_ZONES):
        players.append(Player(id=i + 1, team="home", zone=zone))

    for i, zone in enumerate(AWAY_ZONES):
        players.append(Player(id=i + 12, team="away", zone=zone))

    frames: list[dict] = []
    total_frames = duration_seconds * fps

    for frame_idx in range(total_frames):
        for p in players:
            p.update()

        frames.append({
            "frame_index": frame_idx,
            "timestamp": round(frame_idx / fps, 2),
            "players": [
                {"id": p.id, "team": p.team, "x": round(p.x, 2), "y": round(p.y, 2)}
                for p in players
            ]
        })

    return frames


if __name__ == "__main__":
    print("Generating mock match data...")
    frames = generate_match_data()
    with open("mock_match.json", "w") as f:
        json.dump(frames, f)
    print(f"Saved {len(frames)} frames to mock_match.json")
