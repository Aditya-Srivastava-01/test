# backend/models.py
from datetime import datetime
from sqlalchemy import Column, Integer, String, Float, DateTime, ForeignKey
from database import Base


class Match(Base):
    __tablename__ = "matches"
    id = Column(Integer, primary_key=True, index=True)
    start_time = Column(DateTime, default=datetime.utcnow)
    status = Column(String, default="live")


class TacticalEvent(Base):
    __tablename__ = "tactical_events"
    id = Column(Integer, primary_key=True, index=True)
    match_id = Column(Integer, ForeignKey("matches.id"))
    timestamp = Column(Float)
    event_type = Column(String)
    description = Column(String)
    advice = Column(String)
    created_at = Column(DateTime, default=datetime.utcnow)
