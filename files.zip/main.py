# backend/main.py
import asyncio
import json
import logging
import os
from pathlib import Path

from dotenv import load_dotenv
from fastapi import FastAPI, WebSocket, WebSocketDisconnect, Depends
from fastapi.middleware.cors import CORSMiddleware
from sqlalchemy.orm import Session

import agentic_coach
from database import engine, get_db
import models
import schemas
from mock_data_generator import generate_match_data

load_dotenv()

logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")
logger = logging.getLogger(__name__)

# Create DB tables
models.Base.metadata.create_all(bind=engine)

app = FastAPI(title="CoachAI — Tactical Recommendation Engine")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

# Load or generate match frames once at startup
MATCH_DATA_PATH = Path(__file__).parent / "mock_match.json"

def load_frames() -> list[dict]:
    if MATCH_DATA_PATH.exists():
        logger.info("Loading pre-generated mock_match.json")
        with open(MATCH_DATA_PATH) as f:
            return json.load(f)
    logger.info("Generating match data on-the-fly (no mock_match.json found)")
    return generate_match_data()

FRAMES: list[dict] = load_frames()


@app.get("/")
def root():
    return {"status": "CoachAI running", "total_frames": len(FRAMES)}


@app.get("/events", response_model=list[schemas.TacticalEventResponse])
def get_events(db: Session = Depends(get_db)):
    """Return all stored tactical events."""
    return db.query(models.TacticalEvent).order_by(models.TacticalEvent.id.desc()).all()


@app.websocket("/ws/live-match/{match_id}")
async def live_match(websocket: WebSocket, match_id: str, db: Session = Depends(get_db)):
    await websocket.accept()
    logger.info(f"✅ Client connected — match_id={match_id}")

    # Create a Match record
    match = models.Match(status="live")
    db.add(match)
    db.commit()
    db.refresh(match)

    advice_sent = False  # Only send coaching advice once

    try:
        for frame in FRAMES:
            frame_index: int = frame["frame_index"]

            # Send frame data to client
            await websocket.send_json({
                "type": "frame",
                "timestamp": frame["timestamp"],
                "players": frame["players"],
            })
            logger.info(f"📡 Frame {frame_index:04d} | t={frame['timestamp']:.1f}s")

            # Analyze frame for tactical events
            if not advice_sent:
                triggered, event_type, description = agentic_coach.analyze_frame(
                    frame_index, frame["players"]
                )

                if triggered:
                    logger.warning(f"⚠️  Tactical event detected: {event_type}")
                    advice = await agentic_coach.get_coaching_advice(event_type, description)

                    # Persist event to DB
                    event = models.TacticalEvent(
                        match_id=match.id,
                        timestamp=frame["timestamp"],
                        event_type=event_type,
                        description=description,
                        advice=advice,
                    )
                    db.add(event)
                    db.commit()

                    # Push coaching message to client
                    await websocket.send_json({
                        "type": "coaching",
                        "event": event_type,
                        "description": description,
                        "advice": advice,
                        "timestamp": frame["timestamp"],
                    })
                    logger.info(f"🧠 Coaching advice sent: {advice[:60]}...")
                    advice_sent = True

            await asyncio.sleep(0.1)  # 10 fps

        # Signal match end
        await websocket.send_json({"type": "match_end", "message": "Match simulation complete."})
        match.status = "finished"
        db.commit()
        logger.info("🏁 Match simulation complete.")

    except WebSocketDisconnect:
        logger.info(f"❌ Client disconnected — match_id={match_id}")
        match.status = "disconnected"
        db.commit()
    except Exception as e:
        logger.error(f"🔥 Unexpected error: {e}")
        match.status = "error"
        db.commit()
